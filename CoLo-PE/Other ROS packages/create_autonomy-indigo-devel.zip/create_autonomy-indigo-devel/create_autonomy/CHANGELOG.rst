^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package create_autonomy
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.3.0 (2018-06-10)
------------------
* Migrate to package.xml format 2
    * Minor linting to package files.
* Contributors: Jacob Perron

1.2.0 (2016-10-07)
------------------

1.1.0 (2016-07-23)
------------------

1.0.1 (2016-05-24)
------------------

1.0.0 (2016-04-01)
------------------
* Add ca_description package
* Add ca_msgs to metapackage
* Rename 'create_driver' and 'create_tools' to 'ca_driver' and 'ca_tools'
* Contributors: Jacob Perron

0.4.0 (2016-03-26)
------------------

0.3.0 (2016-03-17)
------------------

0.2.0 (2016-03-03)
------------------

0.1.0 (2016-02-05)
------------------
* Added CI (travis)
* Added create_tools with teleop launch and config files
* Initial commit
* Contributors: Jacob Perron
